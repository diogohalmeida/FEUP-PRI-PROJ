This zip contains all the scripts to extract and process all the information used. 
The Kaggle data is not in the zip because of the size limit of the submission but can be found in this link: https://www.kaggle.com/austinreese/goodreads-books.
This also contains the files to setup SOLR in Docker to be ready to execute queries on the "books" core.