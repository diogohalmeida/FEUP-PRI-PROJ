To run the project we need to install nodejs and the dependencies related with Solr-node.
The datasets used need to be in the folder /data to execute the project. However they are not in this zip due to their size.
To build the docker image and execute it just run the following commands:

docker build . -t solr

docker run --name solr -p 8983:8983 -v ${PWD}/data:/data --rm solr